import model.Account;
import model.CurrentAccount;
import model.FixedDepositAccount;
import model.SavingsAccount;
import service.ReportGenerator;
import service.StatePersister;
import service.TransactionLog;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class Lab11Demo {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        Path dataDir = Path.of("data");
        Path accountsFile = dataDir.resolve("accounts.dat");
        Path logsDir = dataDir.resolve("logs");
        Path logFile = logsDir.resolve("today.log");
        Path reportFile = dataDir.resolve("report.txt");

        Files.deleteIfExists(logFile);

        Account[] accounts = {
            new SavingsAccount("Riya", 5000, 500),
            new CurrentAccount("Karan", 2000, 1000),
            new FixedDepositAccount("Meera", 10000)
        };

        StatePersister.save(accounts, accountsFile);
        Account[] reloaded = StatePersister.load(accountsFile);

        System.out.println("Saved accounts:");
        for (Account account : accounts) {
            System.out.println("  " + account);
        }
        System.out.println("Reloaded accounts:");
        for (Account account : reloaded) {
            System.out.println("  " + account);
        }

        TransactionLog.append(logFile, "DEPOSIT AC0001 500");
        TransactionLog.append(logFile, "WITHDRAW AC0002 200");
        TransactionLog.append(logFile, "DEPOSIT AC0003 1500");
        TransactionLog.append(logFile, "WITHDRAW AC0001 300");
        Files.writeString(logsDir.resolve("empty.log"), "");
        Files.writeString(logsDir.resolve("notes.txt"), "DEPOSIT AC0001 999999");

        System.out.println();
        System.out.println(ReportGenerator.generate(logsDir, reportFile));
    }
}
