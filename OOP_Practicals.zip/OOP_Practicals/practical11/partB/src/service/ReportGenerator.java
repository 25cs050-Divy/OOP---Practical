package service;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.List;

public class ReportGenerator {
    public static String generate(Path logsDir, Path reportFile) throws IOException {
        long totalDeposits = 0;
        long totalWithdrawals = 0;
        List<String> lines = new ArrayList<>();
        lines.add("END OF DAY REPORT");
        lines.add("-----------------");

        try (DirectoryStream<Path> stream = Files.newDirectoryStream(logsDir, "*.log")) {
            for (Path file : stream) {
                BasicFileAttributes attrs = Files.readAttributes(file, BasicFileAttributes.class);
                if (attrs.size() == 0) {
                    continue;
                }
                lines.add("File: " + file.getFileName() + " | size: " + attrs.size()
                        + " bytes | modified: " + attrs.lastModifiedTime());

                try (BufferedReader reader = Files.newBufferedReader(file)) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        String[] parts = line.trim().split("\\s+");
                        if (parts.length < 3) {
                            continue;
                        }
                        long amount;
                        try {
                            amount = Long.parseLong(parts[2]);
                        } catch (NumberFormatException e) {
                            continue;
                        }
                        if (parts[0].equals("DEPOSIT")) {
                            totalDeposits += amount;
                        } else if (parts[0].equals("WITHDRAW")) {
                            totalWithdrawals += amount;
                        }
                    }
                }
            }
        }

        lines.add("Total deposits    : " + totalDeposits);
        lines.add("Total withdrawals : " + totalWithdrawals);
        lines.add("Net change        : " + (totalDeposits - totalWithdrawals));

        if (reportFile.getParent() != null) {
            Files.createDirectories(reportFile.getParent());
        }
        Files.write(reportFile, lines);
        return String.join(System.lineSeparator(), lines);
    }
}
