import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.List;

public class LogAnalyzer {
    public static void main(String[] args) throws IOException {
        Path dir = Files.createTempDirectory("logs");
        Files.write(dir.resolve("app1.log"), List.of(
                "INFO started", "ERROR disk full", "INFO running", "ERROR timeout"));
        Files.write(dir.resolve("app2.log"), List.of(
                "INFO started", "INFO done"));
        Files.write(dir.resolve("app3.log"), List.of(
                "ERROR crash", "INFO restart", "INFO ok"));

        String keyword = "ERROR";
        int totalLines = 0;
        int matching = 0;

        try (DirectoryStream<Path> stream = Files.newDirectoryStream(dir, "*.log")) {
            for (Path file : stream) {
                try (BufferedReader reader = Files.newBufferedReader(file)) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        totalLines++;
                        if (line.contains(keyword)) {
                            matching++;
                        }
                    }
                }
                BasicFileAttributes attrs = Files.readAttributes(file, BasicFileAttributes.class);
                System.out.println(file.getFileName() + " size = " + attrs.size() + " bytes");
            }
        }

        System.out.println("Total lines: " + totalLines);
        System.out.println("Lines containing " + keyword + ": " + matching);

        try (DirectoryStream<Path> stream = Files.newDirectoryStream(dir)) {
            for (Path file : stream) {
                Files.deleteIfExists(file);
            }
        }
        Files.deleteIfExists(dir);
    }
}
