import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class FolderReport {
    public static void main(String[] args) throws IOException {
        Path root = Files.createTempDirectory("tree");
        Files.createDirectories(root.resolve("docs/notes"));
        Files.createDirectories(root.resolve("src"));
        Files.writeString(root.resolve("readme.txt"), "hello");
        Files.writeString(root.resolve("docs/guide.txt"), "guide content here");
        Files.writeString(root.resolve("docs/notes/todo.txt"), "1. write code");
        Files.writeString(root.resolve("src/Main.java"), "class Main {}");

        List<String> report = new ArrayList<>();
        long totalSize = 0;
        int fileCount = 0;

        try (Stream<Path> paths = Files.walk(root)) {
            for (Path path : (Iterable<Path>) paths::iterator) {
                if (!Files.isRegularFile(path)) {
                    continue;
                }
                BasicFileAttributes attrs = Files.readAttributes(path, BasicFileAttributes.class);
                fileCount++;
                totalSize += attrs.size();
                report.add(root.relativize(path) + " | " + attrs.size() + " bytes | " + attrs.lastModifiedTime());
            }
        }

        report.add("Files: " + fileCount + ", total size: " + totalSize + " bytes");

        Path reportFile = Files.createTempFile("report", ".txt");
        Files.write(reportFile, report);

        for (String line : Files.readAllLines(reportFile)) {
            System.out.println(line);
        }

        try (Stream<Path> paths = Files.walk(root)) {
            paths.sorted(java.util.Comparator.reverseOrder()).forEach(p -> p.toFile().delete());
        }
        Files.deleteIfExists(reportFile);
    }
}
