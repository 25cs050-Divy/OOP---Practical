import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.Path;

class Player implements Serializable {
    private static final long serialVersionUID = 1L;

    private final String name;
    private final int score;
    private transient String sessionToken;

    Player(String name, int score, String sessionToken) {
        this.name = name;
        this.score = score;
        this.sessionToken = sessionToken;
    }

    public String toString() {
        return name + " score=" + score + " token=" + sessionToken;
    }
}

public class SaveLoad {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        Player[] players = {
            new Player("Riya", 90, "abc123"),
            new Player("Karan", 75, "xyz789"),
            new Player("Meera", 82, "qwe456")
        };

        Path file = Files.createTempFile("players", ".dat");

        try (ObjectOutputStream out = new ObjectOutputStream(Files.newOutputStream(file))) {
            out.writeObject(players);
        }

        Player[] loaded;
        try (ObjectInputStream in = new ObjectInputStream(Files.newInputStream(file))) {
            loaded = (Player[]) in.readObject();
        }

        System.out.println("Saved:");
        for (Player p : players) {
            System.out.println("  " + p);
        }
        System.out.println("Loaded:");
        for (Player p : loaded) {
            System.out.println("  " + p);
        }

        Files.deleteIfExists(file);
    }
}
