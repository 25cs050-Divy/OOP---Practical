import model.Account;
import model.Command;
import model.SavingsAccount;
import model.TransactionType;
import service.AccountTask;
import service.TransactionBuffer;
import service.TransactionProcessor;
import service.TransferTask;

public class Lab10Demo {
    static void poolDemo() {
        System.out.println("=== Thread pool ===");
        Account account = new SavingsAccount("Riya", 0, 0);
        TransactionProcessor processor = new TransactionProcessor();

        for (int i = 0; i < 100; i++) {
            processor.submit(new AccountTask(account, TransactionType.DEPOSIT, 100));
        }
        for (int i = 0; i < 40; i++) {
            processor.submit(new AccountTask(account, TransactionType.WITHDRAW, 50));
        }
        processor.stop();

        System.out.println("Balance after batch: " + account.getBalance() + " (expected 8000)");
    }

    static void producerConsumerDemo() throws InterruptedException {
        System.out.println("=== Producer - consumer ===");
        Account account = new SavingsAccount("Karan", 0, 0);
        TransactionBuffer buffer = new TransactionBuffer(3);
        int total = 10;

        Thread producer = new Thread(() -> {
            try {
                for (int i = 1; i <= total; i++) {
                    buffer.put(new Command(TransactionType.DEPOSIT, account.getAccountNumber(), i * 100L));
                    System.out.println("Produced deposit " + (i * 100));
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }, "producer");

        Thread consumer = new Thread(() -> {
            try {
                for (int i = 1; i <= total; i++) {
                    Command command = buffer.take();
                    account.deposit(command.amount());
                    System.out.println("    Processed " + command);
                }
            } catch (Exception e) {
                System.out.println("Consumer error: " + e.getMessage());
            }
        }, "consumer");

        producer.start();
        consumer.start();
        producer.join();
        consumer.join();
        System.out.println("Balance: " + account.getBalance() + " (expected 5500)");
    }

    static boolean transfers(boolean ordered) throws InterruptedException {
        Account a = new SavingsAccount("Riya", 5000, 0);
        Account b = new SavingsAccount("Karan", 5000, 0);

        Thread t1 = new Thread(new TransferTask(a, b, 1000, ordered), "T1 (A to B)");
        Thread t2 = new Thread(new TransferTask(b, a, 500, ordered), "T2 (B to A)");
        t1.setDaemon(true);
        t2.setDaemon(true);
        t1.start();
        t2.start();
        t1.join(2000);
        t2.join(2000);

        boolean stuck = t1.isAlive() || t2.isAlive();
        System.out.println("Balances: A=" + a.getBalance() + " B=" + b.getBalance());
        return stuck;
    }

    public static void main(String[] args) throws InterruptedException {
        poolDemo();
        producerConsumerDemo();

        System.out.println("=== Deadlock: opposite lock order ===");
        boolean stuck = transfers(false);
        System.out.println(stuck ? "DEADLOCK: both threads are still blocked" : "Completed");

        System.out.println("=== Fixed: lower account number locked first ===");
        stuck = transfers(true);
        System.out.println(stuck ? "DEADLOCK" : "Completed without deadlock (A=5000-1000+500, B=5000+1000-500)");
    }
}
