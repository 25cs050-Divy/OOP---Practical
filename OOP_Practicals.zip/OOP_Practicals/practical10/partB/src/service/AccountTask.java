package service;

import exception.BankException;
import model.Account;
import model.TransactionType;

public class AccountTask implements Runnable {
    private final Account account;
    private final TransactionType type;
    private final long amount;

    public AccountTask(Account account, TransactionType type, long amount) {
        this.account = account;
        this.type = type;
        this.amount = amount;
    }

    @Override
    public void run() {
        try {
            if (type == TransactionType.DEPOSIT) {
                account.deposit(amount);
            } else if (type == TransactionType.WITHDRAW) {
                account.withdraw(amount);
            }
        } catch (BankException e) {
            System.out.println(Thread.currentThread().getName() + ": " + type + " " + amount + " rejected - " + e.getMessage());
        }
    }
}
