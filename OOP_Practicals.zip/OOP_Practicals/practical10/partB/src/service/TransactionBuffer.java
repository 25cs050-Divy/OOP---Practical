package service;

import model.Command;

public class TransactionBuffer {
    private final Command[] items;
    private int count = 0;
    private int in = 0;
    private int out = 0;

    public TransactionBuffer(int capacity) {
        this.items = new Command[capacity];
    }

    public synchronized void put(Command command) throws InterruptedException {
        while (count == items.length) {
            wait();
        }
        items[in] = command;
        in = (in + 1) % items.length;
        count++;
        notifyAll();
    }

    public synchronized Command take() throws InterruptedException {
        while (count == 0) {
            wait();
        }
        Command command = items[out];
        items[out] = null;
        out = (out + 1) % items.length;
        count--;
        notifyAll();
        return command;
    }
}
