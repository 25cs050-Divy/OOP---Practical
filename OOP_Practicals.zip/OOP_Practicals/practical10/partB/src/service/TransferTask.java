package service;

import exception.BankException;
import model.Account;

public class TransferTask implements Runnable {
    private final Account from;
    private final Account to;
    private final long amount;
    private final boolean ordered;

    public TransferTask(Account from, Account to, long amount, boolean ordered) {
        this.from = from;
        this.to = to;
        this.amount = amount;
        this.ordered = ordered;
    }

    @Override
    public void run() {
        Account first = from;
        Account second = to;
        if (ordered && from.getAccountNumber().compareTo(to.getAccountNumber()) > 0) {
            first = to;
            second = from;
        }

        String name = Thread.currentThread().getName();
        synchronized (first) {
            System.out.println(name + " locked " + first.getAccountNumber());
            try {
                Thread.sleep(150);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            synchronized (second) {
                System.out.println(name + " locked " + second.getAccountNumber());
                try {
                    from.withdraw(amount);
                    to.deposit(amount);
                    System.out.println(name + " moved " + amount + " from " + from.getAccountNumber()
                            + " to " + to.getAccountNumber());
                } catch (BankException e) {
                    System.out.println(name + " failed: " + e.getMessage());
                }
            }
        }
    }
}
