class Buffer {
    private final int[] items;
    private int count = 0;
    private int in = 0;
    private int out = 0;

    Buffer(int capacity) {
        items = new int[capacity];
    }

    synchronized void put(int value) throws InterruptedException {
        while (count == items.length) {
            wait();
        }
        items[in] = value;
        in = (in + 1) % items.length;
        count++;
        notifyAll();
    }

    synchronized int take() throws InterruptedException {
        while (count == 0) {
            wait();
        }
        int value = items[out];
        out = (out + 1) % items.length;
        count--;
        notifyAll();
        return value;
    }
}

public class ProducerConsumer {
    public static void main(String[] args) throws InterruptedException {
        Buffer buffer = new Buffer(3);
        int total = 10;

        Thread producer = new Thread(() -> {
            try {
                for (int i = 1; i <= total; i++) {
                    buffer.put(i);
                    System.out.println("Produced " + i);
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }, "producer");

        Thread consumer = new Thread(() -> {
            try {
                for (int i = 1; i <= total; i++) {
                    int value = buffer.take();
                    System.out.println("    Consumed " + value);
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }, "consumer");

        producer.start();
        consumer.start();
        producer.join();
        consumer.join();
        System.out.println("Produced and consumed " + total + " items in order");
    }
}
