class Resource {
    final String name;
    final int rank;

    Resource(String name, int rank) {
        this.name = name;
        this.rank = rank;
    }
}

public class DeadlockDemo {
    static void use(Resource first, Resource second, String worker) {
        synchronized (first) {
            System.out.println(worker + " locked " + first.name);
            try {
                Thread.sleep(150);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            synchronized (second) {
                System.out.println(worker + " locked " + second.name);
            }
        }
        System.out.println(worker + " finished");
    }

    static void usePrinterAndScanner(Resource printer, Resource scanner, String worker, boolean ordered) {
        Resource first = printer;
        Resource second = scanner;
        if (ordered && printer.rank > scanner.rank) {
            first = scanner;
            second = printer;
        }
        use(first, second, worker);
    }

    static boolean run(boolean ordered) throws InterruptedException {
        Resource printer = new Resource("printer", 1);
        Resource scanner = new Resource("scanner", 2);

        Thread t1 = new Thread(() -> usePrinterAndScanner(printer, scanner, "T1", ordered));
        Thread t2 = new Thread(() -> usePrinterAndScanner(scanner, printer, "T2", ordered));
        t1.setDaemon(true);
        t2.setDaemon(true);
        t1.start();
        t2.start();
        t1.join(2000);
        t2.join(2000);

        return t1.isAlive() || t2.isAlive();
    }

    public static void main(String[] args) throws InterruptedException {
        System.out.println("--- Opposite lock order ---");
        boolean stuck = run(false);
        System.out.println(stuck ? "DEADLOCK: threads are still blocked" : "Completed");

        System.out.println("--- Consistent lock order ---");
        stuck = run(true);
        System.out.println(stuck ? "DEADLOCK: threads are still blocked" : "Completed without deadlock");
    }
}
