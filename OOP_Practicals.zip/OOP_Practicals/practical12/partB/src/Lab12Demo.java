import exception.AccountNotFoundException;
import model.Account;
import model.SavingsAccount;
import service.AccountStore;
import service.TransactionProcessor;

import java.util.ArrayList;
import java.util.Collections;

public class Lab12Demo {
    public static void main(String[] args) {
        AccountStore store = new AccountStore();
        store.add(new SavingsAccount("Riya", 5000, 0));
        store.add(new SavingsAccount("Karan", 2000, 0));
        store.add(new SavingsAccount("Meera", 9000, 0));

        try {
            Account found = store.get("AC0002");
            System.out.println("get(AC0002): " + found);
            store.get("AC0099");
        } catch (AccountNotFoundException e) {
            System.out.println(e.getMessage());
        }

        System.out.println("Sorted by balance (highest first):");
        for (Account account : store.sortedByBalance()) {
            System.out.println("  " + account);
        }

        ArrayList<Account> byNumber = store.getAll();
        Collections.sort(byNumber);
        System.out.println("Sorted by account number (Comparable):");
        for (Account account : byNumber) {
            System.out.println("  " + account);
        }

        System.out.println("History:");
        for (String entry : store.getHistory()) {
            System.out.println("  " + entry);
        }

        TransactionProcessor processor = new TransactionProcessor();
        for (Account account : store.getAll()) {
            processor.register(account);
        }
        System.out.println("Concurrent store lookup AC0003: " + processor.getAccount("AC0003"));
        processor.stop();
    }
}
