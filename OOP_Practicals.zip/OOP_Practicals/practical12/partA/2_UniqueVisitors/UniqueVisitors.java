import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class UniqueVisitors {
    public static void main(String[] args) {
        List<String> logins = List.of("riya", "karan", "riya", "meera", "karan", "arjun", "riya", "dev");

        Set<String> unique = new HashSet<>(logins);
        Set<String> ordered = new LinkedHashSet<>(logins);

        System.out.println("Unique visitors: " + unique.size());

        List<String> firstThree = new ArrayList<>(ordered).subList(0, Math.min(3, ordered.size()));
        System.out.println("First three distinct names: " + firstThree);
    }
}
