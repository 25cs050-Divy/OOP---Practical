import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Leaderboard {
    public static void main(String[] args) {
        Map<String, Integer> scores = new HashMap<>();
        scores.put("Riya", 920);
        scores.put("Karan", 850);
        scores.put("Meera", 920);
        scores.put("Arjun", 700);
        scores.put("Dev", 850);
        scores.put("Isha", 990);

        int topN = 4;

        List<Map.Entry<String, Integer>> entries = new ArrayList<>(scores.entrySet());
        entries.sort(Map.Entry.<String, Integer>comparingByValue(Comparator.reverseOrder())
                .thenComparing(Map.Entry.comparingByKey()));

        for (int i = 0; i < Math.min(topN, entries.size()); i++) {
            Map.Entry<String, Integer> entry = entries.get(i);
            System.out.println((i + 1) + ". " + entry.getKey() + " - " + entry.getValue());
        }
    }
}
