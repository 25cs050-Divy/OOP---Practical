public class Driver {
    public static void main(String[] args) {
        Card[] incoming = {
            new Card("Ace", "Spades"),
            new Card("Queen", "Hearts"),
            new Card("Ten", "Clubs"),
            new Card("Ace", "Spades"),
            new Card("Two", "Diamonds")
        };

        Card[] hand = new Card[incoming.length];
        int count = 0;
        boolean reported = false;

        for (Card card : incoming) {
            for (int i = 0; i < count; i++) {
                if (card.equals(hand[i]) && !reported) {
                    System.out.println("Duplicate found: " + card);
                    reported = true;
                }
            }
            hand[count++] = card;
        }

        if (!reported) {
            System.out.println("No duplicates");
        }
    }
}
