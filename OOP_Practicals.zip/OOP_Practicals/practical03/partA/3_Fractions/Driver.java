public class Driver {
    public static void main(String[] args) {
        Fraction a = new Fraction(1, 2);
        Fraction b = new Fraction(2, 4);
        Fraction c = new Fraction(3, 6);

        System.out.println(a + " " + b + " " + c);
        System.out.println("a equals b: " + a.equals(b));
        System.out.println("b equals c: " + b.equals(c));
        System.out.println("a equals c: " + a.equals(c));
        System.out.println("Same hash codes: " + (a.hashCode() == b.hashCode() && b.hashCode() == c.hashCode()));
    }
}
