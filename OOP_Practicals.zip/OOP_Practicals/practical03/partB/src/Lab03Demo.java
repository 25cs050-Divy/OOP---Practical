public class Lab03Demo {
    public static void main(String[] args) {
        Account a1 = new Account("Riya", 4000);
        Account a2 = new Account("AC0001", "Riya Shah", 9000);
        Account a3 = new Account("Karan", 2500);

        System.out.println(a1);
        System.out.println(a3);
        System.out.println("a1.equals(a2): " + a1.equals(a2));
        System.out.println("a1.equals(a3): " + a1.equals(a3));
        System.out.println("Same hash code for equal accounts: " + (a1.hashCode() == a2.hashCode()));

        Object obj = a1;
        System.out.println("obj instanceof Account: " + (obj instanceof Account));
        Object text = "not an account";
        System.out.println("text instanceof Account: " + (text instanceof Account));

        Customer.Address address = new Customer.Address("12 MG Road", "Anand", "388421");
        Customer customer = new Customer("Riya", "riya@example.com", "9876543210", address);
        Customer copy = customer.clone();

        System.out.println(customer);
        System.out.println("Address: " + customer.getAddress());
        System.out.println("Clone: " + copy);
        System.out.println("Clone is a different object: " + (copy != customer));
        System.out.println("Clone address is a different object: " + (copy.getAddress() != customer.getAddress()));
    }
}
