import model.Account;
import model.SavingsAccount;
import service.AccountWorker;

public class Lab09Demo {
    static final int THREADS = 10;
    static final int DEPOSITS = 1000;

    static long run(boolean safe) throws InterruptedException {
        Account account = new SavingsAccount("Riya", 0, 0);
        Thread[] threads = new Thread[THREADS];

        for (int i = 0; i < THREADS; i++) {
            threads[i] = new Thread(new AccountWorker(account, DEPOSITS, 1, safe), "worker-" + (i + 1));
            System.out.println(threads[i].getName() + " state before start: " + threads[i].getState());
        }
        for (Thread t : threads) {
            t.start();
        }
        for (Thread t : threads) {
            t.join();
        }
        for (Thread t : threads) {
            System.out.println(t.getName() + " state after join: " + t.getState());
        }
        return account.getBalance();
    }

    public static void main(String[] args) throws InterruptedException {
        long expected = (long) THREADS * DEPOSITS;

        System.out.println("=== Without synchronization ===");
        long wrong = run(false);
        System.out.println("Balance: " + wrong + " (expected " + expected + ")");

        System.out.println("=== With synchronization ===");
        long correct = run(true);
        System.out.println("Balance: " + correct + " (expected " + expected + ")");
    }
}
