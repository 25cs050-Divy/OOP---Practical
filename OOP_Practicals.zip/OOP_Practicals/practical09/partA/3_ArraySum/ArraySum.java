import java.util.concurrent.atomic.AtomicLong;

class UnsafeTotal {
    long total = 0;
}

class SynchronizedTotal {
    private long total = 0;

    synchronized void add(long value) {
        total += value;
    }

    long get() {
        return total;
    }
}

public class ArraySum {
    static final int SIZE = 4_000_000;
    static final int THREADS = 4;

    interface Adder {
        void add(long value);
    }

    static long run(int[] data, Adder adder) throws InterruptedException {
        Thread[] threads = new Thread[THREADS];
        int chunk = data.length / THREADS;
        long start = System.nanoTime();
        for (int i = 0; i < THREADS; i++) {
            int from = i * chunk;
            int to = (i == THREADS - 1) ? data.length : from + chunk;
            threads[i] = new Thread(() -> {
                for (int j = from; j < to; j++) {
                    adder.add(data[j]);
                }
            });
            threads[i].start();
        }
        for (Thread t : threads) {
            t.join();
        }
        return System.nanoTime() - start;
    }

    public static void main(String[] args) throws InterruptedException {
        int[] data = new int[SIZE];
        long expected = 0;
        for (int i = 0; i < SIZE; i++) {
            data[i] = (i % 10) + 1;
            expected += data[i];
        }
        System.out.println("Expected total: " + expected);

        UnsafeTotal unsafe = new UnsafeTotal();
        long t1 = run(data, value -> unsafe.total += value);
        System.out.println("Unsafe:        " + unsafe.total + "  (" + t1 / 1_000_000 + " ms)");

        SynchronizedTotal sync = new SynchronizedTotal();
        long t2 = run(data, sync::add);
        System.out.println("Synchronized:  " + sync.get() + "  (" + t2 / 1_000_000 + " ms)");

        AtomicLong atomic = new AtomicLong();
        long t3 = run(data, atomic::addAndGet);
        System.out.println("AtomicLong:    " + atomic.get() + "  (" + t3 / 1_000_000 + " ms)");
    }
}
