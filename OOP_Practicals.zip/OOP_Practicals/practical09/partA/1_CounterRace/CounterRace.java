class UnsafeCounter {
    private int count = 0;

    void increment() {
        int current = count;
        Thread.yield();
        count = current + 1;
    }

    int get() {
        return count;
    }
}

class SafeCounter {
    private int count = 0;

    synchronized void increment() {
        int current = count;
        Thread.yield();
        count = current + 1;
    }

    synchronized int get() {
        return count;
    }
}

public class CounterRace {
    static final int THREADS = 5;
    static final int INCREMENTS = 10000;

    public static void main(String[] args) throws InterruptedException {
        UnsafeCounter unsafe = new UnsafeCounter();
        Thread[] threads = new Thread[THREADS];
        for (int i = 0; i < THREADS; i++) {
            threads[i] = new Thread(() -> {
                for (int j = 0; j < INCREMENTS; j++) {
                    unsafe.increment();
                }
            });
            threads[i].start();
        }
        for (Thread t : threads) {
            t.join();
        }
        System.out.println("Without synchronization: " + unsafe.get() + " (expected " + THREADS * INCREMENTS + ")");

        SafeCounter safe = new SafeCounter();
        for (int i = 0; i < THREADS; i++) {
            threads[i] = new Thread(() -> {
                for (int j = 0; j < INCREMENTS; j++) {
                    safe.increment();
                }
            });
            threads[i].start();
        }
        for (Thread t : threads) {
            t.join();
        }
        System.out.println("With synchronization:    " + safe.get() + " (expected " + THREADS * INCREMENTS + ")");
    }
}
