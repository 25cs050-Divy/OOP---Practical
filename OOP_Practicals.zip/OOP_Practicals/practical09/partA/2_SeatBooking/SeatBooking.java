class UnsafeBooking {
    private int seatsLeft = 5;
    private int booked = 0;

    void book() {
        if (seatsLeft > 0) {
            try {
                Thread.sleep(10);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            seatsLeft--;
            booked++;
        }
    }

    int getBooked() {
        return booked;
    }

    int getSeatsLeft() {
        return seatsLeft;
    }
}

class SafeBooking {
    private int seatsLeft = 5;
    private int booked = 0;

    synchronized void book() {
        if (seatsLeft > 0) {
            try {
                Thread.sleep(10);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            seatsLeft--;
            booked++;
        }
    }

    synchronized int getBooked() {
        return booked;
    }

    synchronized int getSeatsLeft() {
        return seatsLeft;
    }
}

public class SeatBooking {
    public static void main(String[] args) throws InterruptedException {
        int users = 10;

        UnsafeBooking unsafe = new UnsafeBooking();
        Thread[] threads = new Thread[users];
        for (int i = 0; i < users; i++) {
            threads[i] = new Thread(unsafe::book, "user-" + (i + 1));
            threads[i].start();
        }
        for (Thread t : threads) {
            t.join();
        }
        System.out.println("Without synchronization: booked " + unsafe.getBooked()
                + ", seats left " + unsafe.getSeatsLeft());

        SafeBooking safe = new SafeBooking();
        for (int i = 0; i < users; i++) {
            threads[i] = new Thread(safe::book, "user-" + (i + 1));
            threads[i].start();
        }
        for (Thread t : threads) {
            t.join();
        }
        System.out.println("With synchronization:    booked " + safe.getBooked()
                + ", seats left " + safe.getSeatsLeft());
    }
}
