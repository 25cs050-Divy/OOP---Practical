package service;

import exception.AccountNotFoundException;
import exception.BankException;
import exception.InvalidAmountException;
import model.Account;
import model.Command;
import model.CurrentAccount;
import model.FixedDepositAccount;
import model.SavingsAccount;
import model.TransactionType;
import util.CommandParser;
import util.Validator;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

public class BankService {
    private final Repository<Account> repository = new Repository<>();
    private final Path accountsFile;
    private final Path logsDir;
    private final Path logFile;
    private final Path reportFile;

    public BankService(Path dataDir) {
        this.accountsFile = dataDir.resolve("accounts.dat");
        this.logsDir = dataDir.resolve("logs");
        this.logFile = logsDir.resolve("transactions.log");
        this.reportFile = dataDir.resolve("report.txt");
    }

    public int loadState() throws IOException, ClassNotFoundException {
        if (!Files.exists(accountsFile)) {
            return 0;
        }
        Account[] saved = StatePersister.load(accountsFile);
        for (Account account : saved) {
            Account.reserve(account.getAccountNumber());
            repository.save(account);
        }
        return saved.length;
    }

    public void saveState() throws IOException {
        StatePersister.save(repository.findAll().toArray(new Account[0]), accountsFile);
    }

    private synchronized void log(String line) {
        try {
            TransactionLog.append(logFile, line);
        } catch (IOException e) {
            System.out.println("Warning: could not write transaction log - " + e.getMessage());
        }
    }

    public long parseAmount(String text) throws InvalidAmountException {
        if (!Validator.isValidAmount(text)) {
            throw new InvalidAmountException(text);
        }
        return Long.parseLong(text);
    }

    public Account find(String accountNumber) throws AccountNotFoundException {
        String number = accountNumber == null ? "" : accountNumber.trim().toUpperCase();
        if (!Validator.isValidAccountNumber(number)) {
            throw new AccountNotFoundException(accountNumber);
        }
        Account account = repository.findById(number);
        if (account == null) {
            throw new AccountNotFoundException(number);
        }
        return account;
    }

    public Account openAccount(String type, String ownerName, long openingBalance) throws InvalidAmountException {
        if (ownerName == null || ownerName.isBlank()) {
            throw new IllegalArgumentException("Owner name must not be blank");
        }
        if (openingBalance < 0) {
            throw new InvalidAmountException(openingBalance);
        }
        Account account = switch (type.trim().toUpperCase()) {
            case "SAVINGS" -> new SavingsAccount(ownerName.trim(), openingBalance, 500);
            case "CURRENT" -> new CurrentAccount(ownerName.trim(), openingBalance, 5000);
            case "FD" -> new FixedDepositAccount(ownerName.trim(), openingBalance);
            default -> throw new IllegalArgumentException("Unknown account type: " + type);
        };
        repository.save(account);
        log("OPEN " + account.getAccountNumber() + " " + openingBalance);
        return account;
    }

    public void deposit(String accountNumber, long amount) throws BankException {
        Account account = find(accountNumber);
        account.deposit(amount);
        log("DEPOSIT " + account.getAccountNumber() + " " + amount);
    }

    public void withdraw(String accountNumber, long amount) throws BankException {
        Account account = find(accountNumber);
        account.withdraw(amount);
        log("WITHDRAW " + account.getAccountNumber() + " " + amount);
    }

    public void transfer(String fromNumber, String toNumber, long amount) throws BankException {
        Account from = find(fromNumber);
        Account to = find(toNumber);
        from.transfer(to, amount);
        log("TRANSFER " + from.getAccountNumber() + " " + to.getAccountNumber() + " " + amount);
    }

    public String statement(String accountNumber) throws AccountNotFoundException {
        return StatementFormatter.buildStatement(find(accountNumber));
    }

    public List<Account> listAccounts() {
        List<Account> accounts = repository.findAll();
        accounts.sort(Comparator.naturalOrder());
        return accounts;
    }

    public List<Account> searchByOwner(String text) {
        List<Account> matches = new ArrayList<>();
        for (Account account : listAccounts()) {
            if (account.getOwnerName().toLowerCase().contains(text.trim().toLowerCase())) {
                matches.add(account);
            }
        }
        return matches;
    }

    public List<String> processBatch(List<String> lines) {
        ConcurrentLinkedQueue<String> results = new ConcurrentLinkedQueue<>();
        TransactionProcessor processor = new TransactionProcessor();
        for (Account account : repository.findAll()) {
            processor.register(account);
        }

        for (String line : lines) {
            Command command;
            try {
                command = CommandParser.parse(line);
            } catch (IllegalArgumentException e) {
                results.add("Skipped '" + line + "': " + e.getMessage());
                continue;
            }
            Account account = processor.getAccount(command.accountNumber());
            if (account == null) {
                results.add("Skipped '" + line + "': account not found");
                continue;
            }
            processor.submit(() -> {
                try {
                    if (command.type() == TransactionType.DEPOSIT) {
                        account.deposit(command.amount());
                    } else if (command.type() == TransactionType.WITHDRAW) {
                        account.withdraw(command.amount());
                    } else {
                        throw new BankException("Batch supports only DEPOSIT and WITHDRAW");
                    }
                    log(command.type() + " " + command.accountNumber() + " " + command.amount());
                    results.add("OK " + command.type() + " " + command.accountNumber() + " " + command.amount());
                } catch (BankException e) {
                    results.add("Failed '" + line + "': " + e.getMessage());
                }
            });
        }
        processor.stop();
        return new ArrayList<>(results);
    }

    public String report() throws IOException {
        Files.createDirectories(logsDir);
        return ReportGenerator.generate(logsDir, reportFile);
    }
}
