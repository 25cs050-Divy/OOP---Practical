import exception.BankException;
import model.Account;
import service.BankService;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MiniBank {
    private static String ask(Scanner sc, String prompt) {
        System.out.print(prompt);
        return sc.hasNextLine() ? sc.nextLine().trim() : "";
    }

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        BankInfo info = new BankInfo("MiniBank", "Charusat Main Branch");
        System.out.println(info);

        BankService service = new BankService(Path.of("data"));
        int loaded = service.loadState();
        System.out.println("Loaded " + loaded + " saved account(s)");

        Scanner sc = new Scanner(System.in);
        MenuOption[] options = MenuOption.values();
        boolean running = true;

        while (running) {
            System.out.println();
            for (int i = 0; i < options.length; i++) {
                System.out.println((i + 1) + ". " + options[i]);
            }
            if (!sc.hasNextLine()) {
                break;
            }
            System.out.print("Enter your choice: ");
            String input = sc.nextLine().trim();

            int choice;
            try {
                choice = Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Invalid choice, please enter a number from the menu");
                continue;
            }
            if (choice < 1 || choice > options.length) {
                System.out.println("Invalid choice, please enter a number from the menu");
                continue;
            }

            try {
                switch (options[choice - 1]) {
                    case OPEN_ACCOUNT -> {
                        String type = ask(sc, "Type (SAVINGS, CURRENT, FD): ");
                        String owner = ask(sc, "Owner name: ");
                        String openingText = ask(sc, "Opening balance: ");
                        long opening = openingText.equals("0") ? 0 : service.parseAmount(openingText);
                        Account account = service.openAccount(type, owner, opening);
                        System.out.println("Opened " + account);
                    }
                    case DEPOSIT -> {
                        String number = ask(sc, "Account number: ");
                        long amount = service.parseAmount(ask(sc, "Amount: "));
                        service.deposit(number, amount);
                        System.out.println("Deposit successful");
                    }
                    case WITHDRAW -> {
                        String number = ask(sc, "Account number: ");
                        long amount = service.parseAmount(ask(sc, "Amount: "));
                        service.withdraw(number, amount);
                        System.out.println("Withdrawal successful");
                    }
                    case TRANSFER -> {
                        String from = ask(sc, "From account: ");
                        String to = ask(sc, "To account: ");
                        long amount = service.parseAmount(ask(sc, "Amount: "));
                        service.transfer(from, to, amount);
                        System.out.println("Transfer successful");
                    }
                    case STATEMENT -> System.out.println(service.statement(ask(sc, "Account number: ")));
                    case LIST_ACCOUNTS -> {
                        List<Account> accounts = service.listAccounts();
                        if (accounts.isEmpty()) {
                            System.out.println("No accounts yet");
                        }
                        for (Account account : accounts) {
                            System.out.println(account);
                        }
                    }
                    case SEARCH_BY_OWNER -> {
                        for (Account account : service.searchByOwner(ask(sc, "Owner name contains: "))) {
                            System.out.println(account);
                        }
                    }
                    case BATCH -> {
                        System.out.println("Enter commands such as DEPOSIT AC0001 500 (blank line to finish)");
                        List<String> lines = new ArrayList<>();
                        String line = ask(sc, "> ");
                        while (!line.isEmpty()) {
                            lines.add(line);
                            line = ask(sc, "> ");
                        }
                        for (String result : service.processBatch(lines)) {
                            System.out.println(result);
                        }
                    }
                    case REPORT -> System.out.println(service.report());
                    case EXIT -> {
                        service.saveState();
                        System.out.println("Accounts saved. Thank you for using MiniBank. Goodbye!");
                        running = false;
                    }
                }
            } catch (BankException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (IllegalArgumentException e) {
                System.out.println("Invalid input: " + e.getMessage());
            }
        }
        sc.close();
    }
}
