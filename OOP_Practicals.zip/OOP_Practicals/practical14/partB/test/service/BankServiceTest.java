package service;

import exception.InsufficientFundsException;
import model.Account;
import model.TransactionType;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class BankServiceTest {
    private BankService newService() throws IOException {
        return new BankService(Files.createTempDirectory("minibank-test"));
    }

    @Test
    void depositIncreasesBalance() throws Exception {
        BankService service = newService();
        Account account = service.openAccount("SAVINGS", "Riya", 5000);
        service.deposit(account.getAccountNumber(), 2000);
        assertEquals(7000, account.getBalance());
    }

    @Test
    void withdrawalOverTheLimitThrows() throws Exception {
        BankService service = newService();
        Account account = service.openAccount("SAVINGS", "Riya", 1000);
        InsufficientFundsException e = assertThrows(InsufficientFundsException.class,
                () -> service.withdraw(account.getAccountNumber(), 5000));
        assertEquals(4500, e.getShortfall());
        assertEquals(1000, account.getBalance());
    }

    @Test
    void manyConcurrentDepositsKeepBalanceCorrect() throws Exception {
        BankService service = newService();
        Account account = service.openAccount("SAVINGS", "Riya", 0);
        TransactionProcessor processor = new TransactionProcessor();
        processor.register(account);
        for (int i = 0; i < 2000; i++) {
            processor.submit(new AccountTask(account, TransactionType.DEPOSIT, 1));
        }
        processor.stop();
        assertEquals(2000, account.getBalance());
    }

    @Test
    void savedStateLoadsUnchanged() throws Exception {
        Path dir = Files.createTempDirectory("minibank-state");
        BankService first = new BankService(dir);
        Account account = first.openAccount("CURRENT", "Karan", 3000);
        first.deposit(account.getAccountNumber(), 500);
        first.saveState();

        BankService second = new BankService(dir);
        assertEquals(1, second.loadState());
        Account reloaded = second.find(account.getAccountNumber());
        assertEquals(3500, reloaded.getBalance());
        assertEquals("Karan", reloaded.getOwnerName());
    }
}
