package service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class TaskServiceTest {
    @Test
    void addingIncreasesCount() {
        TaskService service = new TaskService();
        service.add("Write report");
        service.add("Submit lab");
        assertEquals(2, service.count());
    }

    @Test
    void blankTitleThrows() {
        TaskService service = new TaskService();
        assertThrows(IllegalArgumentException.class, () -> service.add("   "));
    }

    @Test
    void completingMarksTaskDone() {
        TaskService service = new TaskService();
        service.add("Revise notes");
        service.complete(0);
        assertTrue(service.all().get(0).done());
    }

    @Test
    void invalidIndexThrows() {
        TaskService service = new TaskService();
        assertThrows(IllegalArgumentException.class, () -> service.complete(5));
    }
}
