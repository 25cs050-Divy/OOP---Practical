package model;

public record Task(String title, boolean done) {
    public Task complete() {
        return new Task(title, true);
    }
}
