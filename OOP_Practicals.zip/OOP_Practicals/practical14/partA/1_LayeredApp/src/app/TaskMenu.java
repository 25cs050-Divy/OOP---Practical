package app;

import model.Task;
import service.TaskService;

import java.util.List;
import java.util.Scanner;

public class TaskMenu {
    public static void main(String[] args) {
        TaskService service = new TaskService();
        Scanner sc = new Scanner(System.in);
        boolean running = true;

        while (running) {
            System.out.println();
            System.out.println("1. Add task");
            System.out.println("2. Complete task");
            System.out.println("3. List tasks");
            System.out.println("4. Exit");
            System.out.print("Choice: ");
            if (!sc.hasNextLine()) {
                break;
            }
            String choice = sc.nextLine().trim();
            try {
                switch (choice) {
                    case "1" -> {
                        System.out.print("Title: ");
                        service.add(sc.nextLine());
                        System.out.println("Added");
                    }
                    case "2" -> {
                        System.out.print("Task number: ");
                        service.complete(Integer.parseInt(sc.nextLine().trim()) - 1);
                        System.out.println("Completed");
                    }
                    case "3" -> {
                        List<Task> all = service.all();
                        for (int i = 0; i < all.size(); i++) {
                            Task t = all.get(i);
                            System.out.println((i + 1) + ". [" + (t.done() ? "x" : " ") + "] " + t.title());
                        }
                        System.out.println("Total: " + service.count());
                    }
                    case "4" -> running = false;
                    default -> System.out.println("Invalid choice");
                }
            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
        System.out.println("Goodbye");
        sc.close();
    }
}
