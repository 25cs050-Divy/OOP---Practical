JUNIT=junit-platform-console-standalone.jar
rm -rf out
mkdir -p out
javac -d out -cp $JUNIT $(find src test -name "*.java")
java -jar $JUNIT execute -cp out --scan-classpath
