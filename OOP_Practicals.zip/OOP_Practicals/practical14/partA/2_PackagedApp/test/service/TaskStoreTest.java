package service;

import model.Task;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TaskStoreTest {
    @Test
    void savedTasksReloadUnchanged() throws IOException, ClassNotFoundException {
        Path file = Files.createTempFile("tasks", ".dat");
        TaskService service = new TaskService();
        service.add("First");
        service.add("Second");
        service.complete(1);

        TaskStore.save(service.all(), file);
        List<Task> loaded = TaskStore.load(file);

        assertEquals(service.all(), loaded);
        Files.deleteIfExists(file);
    }

    @Test
    void missingFileLoadsEmptyList() throws IOException, ClassNotFoundException {
        Path file = Path.of("does-not-exist.dat");
        assertEquals(0, TaskStore.load(file).size());
    }
}
