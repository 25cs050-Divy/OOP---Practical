package model;

import java.io.Serializable;

public record Task(String title, boolean done) implements Serializable {
    public Task complete() {
        return new Task(title, true);
    }
}
