package service;

import model.Task;

import java.util.ArrayList;
import java.util.List;

public class TaskService {
    private final List<Task> tasks = new ArrayList<>();

    public TaskService() {
    }

    public TaskService(List<Task> existing) {
        tasks.addAll(existing);
    }

    public void add(String title) {
        if (title == null || title.isBlank()) {
            throw new IllegalArgumentException("Title must not be blank");
        }
        tasks.add(new Task(title.trim(), false));
    }

    public void complete(int index) {
        if (index < 0 || index >= tasks.size()) {
            throw new IllegalArgumentException("No task at position " + (index + 1));
        }
        tasks.set(index, tasks.get(index).complete());
    }

    public int count() {
        return tasks.size();
    }

    public List<Task> all() {
        return new ArrayList<>(tasks);
    }
}
