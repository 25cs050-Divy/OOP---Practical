rm -rf out
mkdir -p out
javac -d out $(find src -name "*.java")
jar cfm taskapp.jar MANIFEST.MF -C out .
java -jar taskapp.jar
