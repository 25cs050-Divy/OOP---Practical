import java.util.HashMap;
import java.util.Map;

class OutOfStockException extends Exception {
    private final int shortfall;

    OutOfStockException(String item, int shortfall) {
        super("Out of stock: " + item + ", short by " + shortfall);
        this.shortfall = shortfall;
    }

    int getShortfall() {
        return shortfall;
    }
}

class InvalidQuantityException extends Exception {
    InvalidQuantityException(int qty) {
        super("Invalid quantity: " + qty);
    }
}

class Warehouse {
    private final Map<String, Integer> stock = new HashMap<>();

    void add(String item, int qty) {
        stock.merge(item, qty, Integer::sum);
    }

    void issue(String item, int qty) throws OutOfStockException, InvalidQuantityException {
        if (qty <= 0) {
            throw new InvalidQuantityException(qty);
        }
        int available = stock.getOrDefault(item, 0);
        if (qty > available) {
            throw new OutOfStockException(item, qty - available);
        }
        stock.put(item, available - qty);
    }

    int level(String item) {
        return stock.getOrDefault(item, 0);
    }
}

public class StockIssue {
    public static void main(String[] args) {
        Warehouse warehouse = new Warehouse();
        warehouse.add("Keyboard", 10);
        warehouse.add("Mouse", 5);
        warehouse.add("Monitor", 2);

        String[] items = {"Keyboard", "Mouse", "Monitor", "Keyboard", "Mouse"};
        int[] quantities = {4, 8, 2, -3, 5};

        int succeeded = 0;
        int failed = 0;
        for (int i = 0; i < items.length; i++) {
            try {
                warehouse.issue(items[i], quantities[i]);
                succeeded++;
                System.out.println("Issued " + quantities[i] + " x " + items[i]);
            } catch (OutOfStockException e) {
                failed++;
                System.out.println(e.getMessage() + " (shortfall " + e.getShortfall() + ")");
            } catch (InvalidQuantityException e) {
                failed++;
                System.out.println(e.getMessage());
            }
        }

        System.out.println("Succeeded: " + succeeded + ", failed: " + failed);
        System.out.println("Keyboards left: " + warehouse.level("Keyboard"));
    }
}
