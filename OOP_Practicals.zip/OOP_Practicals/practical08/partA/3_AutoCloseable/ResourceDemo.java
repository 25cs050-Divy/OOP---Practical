class Session implements AutoCloseable {
    private final String name;

    Session(String name) {
        this.name = name;
        System.out.println("Opened " + name);
    }

    void work(boolean fail) {
        System.out.println("Working in " + name);
        if (fail) {
            throw new IllegalStateException("work failed in " + name);
        }
    }

    public void close() {
        System.out.println("Closed " + name);
        throw new IllegalStateException("close failed in " + name);
    }
}

public class ResourceDemo {
    public static void main(String[] args) {
        System.out.println("--- Normal run ---");
        try (Session s = new Session("session-1")) {
            s.work(false);
        } catch (IllegalStateException e) {
            System.out.println("Reported: " + e.getMessage());
        }

        System.out.println("--- Exception inside the block ---");
        try (Session s = new Session("session-2")) {
            s.work(true);
        } catch (IllegalStateException e) {
            System.out.println("Reported: " + e.getMessage());
            for (Throwable suppressed : e.getSuppressed()) {
                System.out.println("Suppressed: " + suppressed.getMessage());
            }
        }
    }
}
