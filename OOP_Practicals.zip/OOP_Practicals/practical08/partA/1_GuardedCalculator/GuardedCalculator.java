import java.util.Scanner;

class DivideByZeroException extends Exception {
    DivideByZeroException(String message) {
        super(message);
    }
}

public class GuardedCalculator {
    static double calculate(double a, double b, char op) throws DivideByZeroException {
        switch (op) {
            case '+':
                return a + b;
            case '-':
                return a - b;
            case '*':
                return a * b;
            case '/':
                if (b == 0) {
                    throw new DivideByZeroException("Cannot divide by zero");
                }
                return a / b;
            default:
                throw new IllegalArgumentException("Unknown operator: " + op);
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int attempt = 0;
        boolean done = false;

        while (!done) {
            attempt++;
            try {
                System.out.print("First number: ");
                double a = Double.parseDouble(sc.nextLine().trim());
                System.out.print("Operator (+, -, *, /): ");
                char op = sc.nextLine().trim().charAt(0);
                System.out.print("Second number: ");
                double b = Double.parseDouble(sc.nextLine().trim());

                double result = calculate(a, b, op);
                System.out.println("Result: " + result);
                done = true;
            } catch (NumberFormatException e) {
                System.out.println("Invalid number, please enter digits only");
            } catch (DivideByZeroException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (IllegalArgumentException | StringIndexOutOfBoundsException e) {
                System.out.println("Invalid operator, use one of + - * /");
            } finally {
                System.out.println("[log] attempt " + attempt + " finished");
            }
        }
        sc.close();
    }
}
