package util;

public class AuditSession implements AutoCloseable {
    private final String name;

    public AuditSession(String name) {
        this.name = name;
        System.out.println("Audit session opened: " + name);
    }

    public void record(String event) {
        System.out.println("[" + name + "] " + event);
    }

    @Override
    public void close() {
        System.out.println("Audit session closed: " + name);
    }
}
