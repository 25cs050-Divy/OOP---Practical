import exception.AccountNotFoundException;
import exception.BankException;
import exception.InsufficientFundsException;
import exception.InvalidAmountException;
import model.Account;
import model.SavingsAccount;
import util.AuditSession;

public class Lab08Demo {
    static Account find(Account[] accounts, String number) throws AccountNotFoundException {
        for (Account account : accounts) {
            if (account.getAccountNumber().equals(number)) {
                return account;
            }
        }
        throw new AccountNotFoundException(number);
    }

    public static void main(String[] args) {
        Account riya = new SavingsAccount("Riya", 1000, 0);
        Account karan = new SavingsAccount("Karan", 3000, 0);
        Account[] accounts = {riya, karan};

        try {
            riya.withdraw(5000);
        } catch (InsufficientFundsException e) {
            System.out.println("Withdrawal failed: short by " + e.getShortfall());
        } catch (InvalidAmountException e) {
            System.out.println("Withdrawal failed: " + e.getMessage());
        } finally {
            System.out.println("Balance is still " + riya.getBalance());
        }

        try {
            riya.deposit(-50);
        } catch (InvalidAmountException e) {
            System.out.println("Deposit failed: " + e.getMessage());
        }

        try {
            riya.transfer(karan, 400);
            System.out.println("Transfer ok: " + riya.getBalance() + " / " + karan.getBalance());
            riya.transfer(karan, 9000);
        } catch (BankException e) {
            System.out.println("Transfer failed: " + e.getMessage());
        }

        try {
            find(accounts, "AC9999");
        } catch (AccountNotFoundException e) {
            System.out.println(e.getMessage());
        }

        try (AuditSession audit = new AuditSession("end-of-day")) {
            audit.record("Riya balance " + riya.getBalance());
            audit.record("Karan balance " + karan.getBalance());
        }
    }
}
