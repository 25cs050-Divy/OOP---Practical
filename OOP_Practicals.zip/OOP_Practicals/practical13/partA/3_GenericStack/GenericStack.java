class ArrayStack<T> {
    private Object[] items = new Object[2];
    private int size = 0;

    void push(T item) {
        if (size == items.length) {
            Object[] bigger = new Object[items.length * 2];
            System.arraycopy(items, 0, bigger, 0, size);
            items = bigger;
        }
        items[size++] = item;
    }

    @SuppressWarnings("unchecked")
    T pop() {
        if (size == 0) {
            return null;
        }
        T item = (T) items[--size];
        items[size] = null;
        return item;
    }

    @SuppressWarnings("unchecked")
    T peek() {
        return size == 0 ? null : (T) items[size - 1];
    }

    boolean isEmpty() {
        return size == 0;
    }

    int size() {
        return size;
    }
}

public class GenericStack {
    public static void main(String[] args) {
        ArrayStack<Integer> numbers = new ArrayStack<>();
        for (int i = 1; i <= 5; i++) {
            numbers.push(i * 10);
        }
        System.out.println("Peek: " + numbers.peek());
        while (!numbers.isEmpty()) {
            System.out.println("Popped: " + numbers.pop());
        }
        System.out.println("Pop on empty stack: " + numbers.pop());

        ArrayStack<String> words = new ArrayStack<>();
        words.push("one");
        words.push("two");
        words.push("three");
        System.out.println("Size: " + words.size());
        System.out.println("Popped: " + words.pop());
        System.out.println("Popped: " + words.pop());
    }
}
