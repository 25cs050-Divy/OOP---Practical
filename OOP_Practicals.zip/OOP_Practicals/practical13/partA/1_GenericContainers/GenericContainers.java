class Box<T> {
    private T value;

    Box(T value) {
        this.value = value;
    }

    T get() {
        return value;
    }

    void set(T value) {
        this.value = value;
    }
}

class Pair<A, B> {
    private final A first;
    private final B second;

    Pair(A first, B second) {
        this.first = first;
        this.second = second;
    }

    A getFirst() {
        return first;
    }

    B getSecond() {
        return second;
    }

    public String toString() {
        return "(" + first + ", " + second + ")";
    }
}

public class GenericContainers {
    static <T> T firstOf(T[] array) {
        return array.length == 0 ? null : array[0];
    }

    public static void main(String[] args) {
        Box<Integer> intBox = new Box<>(42);
        int number = intBox.get() + 8;
        System.out.println("Integer box: " + number);

        Box<String> stringBox = new Box<>("hello");
        String text = stringBox.get().toUpperCase();
        System.out.println("String box: " + text);

        Pair<String, Integer> pair = new Pair<>("Riya", 50);
        String name = pair.getFirst();
        int roll = pair.getSecond();
        System.out.println("Pair: " + pair + " -> " + name + ", " + roll);

        String[] names = {"alpha", "beta", "gamma"};
        Integer[] numbers = {10, 20, 30};
        System.out.println("First name: " + firstOf(names));
        System.out.println("First number: " + firstOf(numbers));
    }
}
