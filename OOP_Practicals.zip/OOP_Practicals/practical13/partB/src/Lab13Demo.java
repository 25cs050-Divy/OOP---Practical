import model.Account;
import model.Customer;
import model.SavingsAccount;
import service.Repository;

public class Lab13Demo {
    public static void main(String[] args) {
        Repository<Account> accounts = new Repository<>();
        accounts.save(new SavingsAccount("Riya", 5000, 0));
        accounts.saveAll(
                new SavingsAccount("Karan", 2000, 0),
                new SavingsAccount("Meera", 9000, 0));

        System.out.println("findById(AC0002): " + accounts.findById("AC0002"));
        System.out.println("findById(AC0099): " + accounts.findById("AC0099"));
        System.out.println("All accounts (" + accounts.count() + "):");
        for (Account account : accounts.findAll()) {
            System.out.println("  " + account);
        }
        System.out.println("delete(AC0001): " + accounts.delete("AC0001"));
        System.out.println("Remaining: " + accounts.count());

        Repository<Customer> customers = new Repository<>();
        customers.saveAll(
                new Customer("Riya", "riya@example.com", "9876543210"),
                new Customer("Karan", "karan@example.com", "9123456780"));
        System.out.println("Customers (" + customers.count() + "):");
        for (Customer customer : customers.findAll()) {
            System.out.println("  " + customer);
        }
        System.out.println("findById(CUST102): " + customers.findById("CUST102"));

        Integer[] numbers = {10, 20, 30};
        Double[] decimals = {1.5, 2.5};
        System.out.println("average(Integer[]): " + Repository.average(numbers));
        System.out.println("average(Double[]): " + Repository.average(decimals));
    }
}
