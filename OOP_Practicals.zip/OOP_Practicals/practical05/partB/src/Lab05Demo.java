public class Lab05Demo {
    public static void main(String[] args) {
        Account[] accounts = {
            new SavingsAccount("Riya", 5000, 1000),
            new CurrentAccount("Karan", 2000, 3000),
            new FixedDepositAccount("Meera", 10000)
        };

        for (Account account : accounts) {
            System.out.println(account + " -> interest rate " + account.interestRate());

            if (account instanceof SavingsAccount savings) {
                System.out.println("  Savings account with minimum balance " + savings.getMinBalance());
            } else if (account instanceof CurrentAccount current) {
                System.out.println("  Current account with overdraft limit " + current.getOverdraftLimit());
            }

            boolean ok = account.withdraw(4500);
            System.out.println("  withdraw(4500): " + ok + ", balance " + account.getBalance());
        }
    }
}
