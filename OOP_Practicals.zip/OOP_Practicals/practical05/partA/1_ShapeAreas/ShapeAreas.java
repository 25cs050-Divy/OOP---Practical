abstract class Shape {
    abstract double area();
}

class Circle extends Shape {
    private double radius;

    Circle(double radius) {
        this.radius = radius;
    }

    double area() {
        return Math.PI * radius * radius;
    }
}

class Rectangle extends Shape {
    private double width;
    private double height;

    Rectangle(double width, double height) {
        this.width = width;
        this.height = height;
    }

    double area() {
        return width * height;
    }
}

class Triangle extends Shape {
    private double base;
    private double height;

    Triangle(double base, double height) {
        this.base = base;
        this.height = height;
    }

    double area() {
        return 0.5 * base * height;
    }
}

public class ShapeAreas {
    public static void main(String[] args) {
        Shape[] shapes = {
            new Circle(3),
            new Rectangle(4, 5),
            new Triangle(6, 7),
            new Circle(1.5),
            new Rectangle(2, 2)
        };

        double total = 0;
        Shape largest = null;

        for (Shape shape : shapes) {
            double area = shape.area();
            total += area;
            if (largest == null || area > largest.area()) {
                largest = shape;
            }
            System.out.printf("%-10s area = %8.2f   running total = %8.2f%n",
                    shape.getClass().getSimpleName(), area, total);
        }

        System.out.printf("Largest: %s with area %.2f%n",
                largest.getClass().getSimpleName(), largest.area());
    }
}
