abstract class Employee {
    private String name;
    private int id;

    Employee(String name, int id) {
        this.name = name;
        this.id = id;
    }

    String getName() {
        return name;
    }

    int getId() {
        return id;
    }

    abstract double monthlySalary();
}

class FullTime extends Employee {
    private double fixedSalary;

    FullTime(String name, int id, double fixedSalary) {
        super(name, id);
        this.fixedSalary = fixedSalary;
    }

    double monthlySalary() {
        return fixedSalary;
    }
}

class PartTime extends Employee {
    private int hours;
    private double rate;

    PartTime(String name, int id, int hours, double rate) {
        super(name, id);
        this.hours = hours;
        this.rate = rate;
    }

    double monthlySalary() {
        return hours * rate;
    }
}

class Intern extends Employee {
    private double stipend;

    Intern(String name, int id, double stipend) {
        super(name, id);
        this.stipend = stipend;
    }

    double monthlySalary() {
        return stipend;
    }
}

public class Payroll {
    public static void main(String[] args) {
        Employee[] staff = {
            new FullTime("Riya", 101, 60000),
            new PartTime("Karan", 102, 80, 400),
            new Intern("Meera", 103, 12000),
            new FullTime("Arjun", 104, 55000),
            new Intern("Dev", 105, 10000)
        };

        double total = 0;
        for (Employee e : staff) {
            double salary = e.monthlySalary();
            total += salary;
            String line = e.getId() + " " + e.getName() + " : " + salary;
            if (e instanceof Intern) {
                line += "  (intern - stipend only)";
            }
            System.out.println(line);
        }
        System.out.println("Total payroll: " + total);
    }
}
