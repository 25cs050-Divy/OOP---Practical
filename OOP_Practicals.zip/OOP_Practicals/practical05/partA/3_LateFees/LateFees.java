abstract class LibraryItem {
    private String title;

    LibraryItem(String title) {
        this.title = title;
    }

    String getTitle() {
        return title;
    }

    abstract double lateFee(int daysLate);
}

class Book extends LibraryItem {
    Book(String title) {
        super(title);
    }

    double lateFee(int daysLate) {
        return daysLate * 2.0;
    }
}

class Dvd extends LibraryItem {
    Dvd(String title) {
        super(title);
    }

    double lateFee(int daysLate) {
        return Math.min(daysLate * 5.0, 100.0);
    }
}

class Magazine extends LibraryItem {
    Magazine(String title) {
        super(title);
    }

    double lateFee(int daysLate) {
        if (daysLate <= 7) {
            return daysLate * 1.0;
        }
        return 7 * 1.0 + (daysLate - 7) * 3.0;
    }
}

public class LateFees {
    public static void main(String[] args) {
        LibraryItem[] returned = {
            new Book("Clean Code"),
            new Dvd("Inception"),
            new Magazine("National Geographic"),
            new Book("Effective Java"),
            new Dvd("Interstellar")
        };
        int[] daysLate = {3, 30, 10, 0, 5};

        double total = 0;
        for (int i = 0; i < returned.length; i++) {
            double fee = returned[i].lateFee(daysLate[i]);
            total += fee;
            System.out.println(returned[i].getTitle() + " (" + returned[i].getClass().getSimpleName()
                    + "), " + daysLate[i] + " days late: " + fee);
        }
        System.out.println("Total late fees: " + total);
    }
}
