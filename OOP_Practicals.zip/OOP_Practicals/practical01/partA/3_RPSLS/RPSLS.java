import java.util.Random;
import java.util.Scanner;

enum Move {
    ROCK, PAPER, SCISSORS, LIZARD, SPOCK
}

public class RPSLS {
    static int winner(Move a, Move b) {
        if (a == b) {
            return 0;
        }
        boolean aWins = switch (a) {
            case SCISSORS -> b == Move.PAPER || b == Move.LIZARD;
            case PAPER -> b == Move.ROCK || b == Move.SPOCK;
            case ROCK -> b == Move.LIZARD || b == Move.SCISSORS;
            case LIZARD -> b == Move.SPOCK || b == Move.PAPER;
            case SPOCK -> b == Move.SCISSORS || b == Move.ROCK;
        };
        return aWins ? 1 : -1;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random random = new Random();
        Move[] moves = Move.values();
        int player = 0;
        int computer = 0;

        for (int round = 1; round <= 5; round++) {
            Move computerMove = moves[random.nextInt(moves.length)];
            Move playerMove = null;
            while (playerMove == null) {
                System.out.print("Round " + round + " - your move (ROCK, PAPER, SCISSORS, LIZARD, SPOCK): ");
                if (!sc.hasNextLine()) {
                    return;
                }
                try {
                    playerMove = Move.valueOf(sc.nextLine().trim().toUpperCase());
                } catch (IllegalArgumentException e) {
                    System.out.println("Invalid move");
                }
            }

            int result = winner(playerMove, computerMove);
            System.out.println("You: " + playerMove + "  Computer: " + computerMove);
            if (result > 0) {
                player++;
                System.out.println("Round winner: You");
            } else if (result < 0) {
                computer++;
                System.out.println("Round winner: Computer");
            } else {
                System.out.println("Round winner: Tie");
            }
        }

        if (player > computer) {
            System.out.println("You win " + player + "-" + computer);
        } else if (computer > player) {
            System.out.println("Computer wins " + computer + "-" + player);
        } else {
            System.out.println("It is a draw " + player + "-" + computer);
        }
        sc.close();
    }
}
