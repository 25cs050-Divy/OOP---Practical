import java.util.Scanner;

record Vehicle(String number, String type) {
}

public class TollBooth {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int total = 0;
        int bike = 0;
        int car = 0;
        int truck = 0;

        while (true) {
            System.out.print("Vehicle number (or done): ");
            if (!sc.hasNextLine()) {
                break;
            }
            String number = sc.nextLine().trim();
            if (number.equalsIgnoreCase("done")) {
                break;
            }
            System.out.print("Vehicle type (bike, car, truck): ");
            if (!sc.hasNextLine()) {
                break;
            }
            String type = sc.nextLine().trim().toLowerCase();
            Vehicle vehicle = new Vehicle(number, type);

            int toll = switch (vehicle.type()) {
                case "bike" -> 20;
                case "car" -> 50;
                case "truck" -> 150;
                default -> 0;
            };
            if (toll == 0) {
                System.out.println("Unknown vehicle type");
                continue;
            }

            total += toll;
            switch (vehicle.type()) {
                case "bike" -> bike++;
                case "car" -> car++;
                default -> truck++;
            }
            System.out.println(vehicle + " toll: " + toll);
        }

        String most = "bike";
        int max = bike;
        if (car > max) {
            most = "car";
            max = car;
        }
        if (truck > max) {
            most = "truck";
        }

        System.out.println("Total toll: " + total);
        System.out.println("Most frequent: " + most);
        sc.close();
    }
}
