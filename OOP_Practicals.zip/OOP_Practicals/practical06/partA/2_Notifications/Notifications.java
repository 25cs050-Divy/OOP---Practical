@FunctionalInterface
interface Notifier {
    void send(String message);
}

interface Urgent {
}

public class Notifications {
    public static void main(String[] args) {
        Notifier[] senders = {
            message -> System.out.println("EMAIL: " + message),
            (Notifier & Urgent) message -> System.out.println("SMS: " + message),
            message -> System.out.println("PUSH: " + message)
        };

        String message = "Server maintenance at midnight";
        for (Notifier sender : senders) {
            sender.send(message);
            if (sender instanceof Urgent) {
                sender.send(message);
            }
        }
    }
}
