interface Switchable {
    void on();

    void off();

    boolean isOn();

    default void toggle() {
        if (isOn()) {
            off();
        } else {
            on();
        }
    }
}

class Fan implements Switchable {
    private boolean running;

    public void on() {
        running = true;
        System.out.println("Fan is ON");
    }

    public void off() {
        running = false;
        System.out.println("Fan is OFF");
    }

    public boolean isOn() {
        return running;
    }
}

class Light implements Switchable {
    private boolean lit;

    public void on() {
        lit = true;
        System.out.println("Light is ON");
    }

    public void off() {
        lit = false;
        System.out.println("Light is OFF");
    }

    public boolean isOn() {
        return lit;
    }
}

@FunctionalInterface
interface SwitchPolicy {
    boolean maySwitchOn(Switchable device, int hour);
}

public class RemoteControl {
    public static void main(String[] args) {
        Switchable[] devices = {new Fan(), new Light()};

        for (Switchable device : devices) {
            device.toggle();
        }
        for (Switchable device : devices) {
            device.toggle();
        }

        SwitchPolicy anonymousPolicy = new SwitchPolicy() {
            public boolean maySwitchOn(Switchable device, int hour) {
                if (device instanceof Light) {
                    return hour >= 18 || hour < 6;
                }
                return true;
            }
        };

        SwitchPolicy lambdaPolicy = (device, hour) -> {
            if (device instanceof Light) {
                return hour >= 18 || hour < 6;
            }
            return true;
        };

        int[] hours = {3, 12, 20};
        for (int hour : hours) {
            for (Switchable device : devices) {
                String name = device.getClass().getSimpleName();
                System.out.println(name + " at " + hour + ":00 -> anonymous: "
                        + anonymousPolicy.maySwitchOn(device, hour)
                        + ", lambda: " + lambdaPolicy.maySwitchOn(device, hour));
            }
        }
    }
}
