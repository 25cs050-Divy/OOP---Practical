package discount.app;

import discount.engine.DiscountRule;
import discount.engine.Rules;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class DiscountApp {
    public static void main(String[] args) {
        List<Double> prices = new ArrayList<>(List.of(120.0, 450.0, 999.0, 60.0, 520.0));
        Map<String, DiscountRule> rules = Rules.all();
        List<String> names = new ArrayList<>(rules.keySet());
        Scanner sc = new Scanner(System.in);

        System.out.println("Choose a discount rule:");
        for (int i = 0; i < names.size(); i++) {
            System.out.println((i + 1) + ". " + names.get(i));
        }
        System.out.print("Choice: ");
        int choice = sc.hasNextInt() ? sc.nextInt() : 4;
        if (choice < 1 || choice > names.size()) {
            choice = names.size();
        }

        String chosen = names.get(choice - 1);
        DiscountRule rule = rules.get(chosen);
        System.out.println("Applying: " + chosen);

        double before = 0;
        double after = 0;
        for (double price : prices) {
            double discounted = rule.apply(price);
            before += price;
            after += discounted;
            System.out.printf("%8.2f -> %8.2f%n", price, discounted);
        }
        System.out.printf("Total: %.2f -> %.2f%n", before, after);
        sc.close();
    }
}
