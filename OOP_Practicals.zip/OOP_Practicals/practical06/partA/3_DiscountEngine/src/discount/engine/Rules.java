package discount.engine;

import java.util.LinkedHashMap;
import java.util.Map;

public class Rules {
    public static Map<String, DiscountRule> all() {
        Map<String, DiscountRule> rules = new LinkedHashMap<>();
        rules.put("10% off", price -> price * 0.90);
        rules.put("Flat 50 off", price -> Math.max(0, price - 50));
        rules.put("20% off above 500", price -> price > 500 ? price * 0.80 : price);
        rules.put("No discount", price -> price);
        return rules;
    }
}
