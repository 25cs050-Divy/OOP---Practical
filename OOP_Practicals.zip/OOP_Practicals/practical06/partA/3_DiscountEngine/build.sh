rm -rf out
mkdir -p out
javac -d out $(find src -name "*.java")
jar cfm discount.jar MANIFEST.MF -C out .
java -jar discount.jar
