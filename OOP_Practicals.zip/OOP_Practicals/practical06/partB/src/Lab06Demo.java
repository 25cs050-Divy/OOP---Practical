import model.Account;
import model.CurrentAccount;
import model.FixedDepositAccount;
import model.Premium;
import model.SavingsAccount;
import model.WithdrawRule;
import service.StatementFormatter;

import static util.Validator.isValidMobile;

public class Lab06Demo {
    public static void main(String[] args) {
        Account savings = new SavingsAccount("Riya", 20000, 1000);
        Account current = new CurrentAccount("Karan", 5000, 2000);
        Account fixed = new FixedDepositAccount("Meera", 50000);

        for (Account account : new Account[] {savings, current, fixed}) {
            System.out.println(account.getAccountNumber() + " yearly interest: " + account.yearlyInterest()
                    + ", monthly interest: " + account.monthlyInterest());
            System.out.println("  premium account: " + (account instanceof Premium));
        }

        WithdrawRule anonymousRule = new WithdrawRule() {
            public boolean allow(Account account, long amount) {
                return amount <= 10000 && account.canWithdraw(amount);
            }
        };

        WithdrawRule lambdaRule = (account, amount) -> amount <= 10000 && account.canWithdraw(amount);

        long[] amounts = {500, 15000, 25000};
        for (long amount : amounts) {
            boolean viaAnonymous = anonymousRule.allow(savings, amount);
            boolean viaLambda = lambdaRule.allow(savings, amount);
            System.out.println("Savings, amount " + amount + " -> anonymous: " + viaAnonymous
                    + ", lambda: " + viaLambda + ", same: " + (viaAnonymous == viaLambda));
        }

        System.out.println("isValidMobile(9876543210): " + isValidMobile("9876543210"));
        System.out.println(StatementFormatter.buildStatement(savings));
    }
}
