rm -rf out
mkdir -p out
javac -d out $(find src -name "*.java")
jar cfm minibank.jar MANIFEST.MF -C out .
java -jar minibank.jar
