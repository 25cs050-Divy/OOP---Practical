package util;

import model.annotation.MaxLength;
import model.annotation.Positive;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public class AnnotationValidator {
    public static String[] validate(Object obj) {
        List<String> errors = new ArrayList<>();
        Class<?> type = obj.getClass();
        while (type != null) {
            for (Field field : type.getDeclaredFields()) {
                field.setAccessible(true);
                Object value;
                try {
                    value = field.get(obj);
                } catch (IllegalAccessException e) {
                    continue;
                }

                if (field.isAnnotationPresent(Positive.class) && value instanceof Number number) {
                    if (number.doubleValue() <= 0) {
                        errors.add(field.getAnnotation(Positive.class).message());
                    }
                }

                if (field.isAnnotationPresent(MaxLength.class) && value instanceof String text) {
                    int max = field.getAnnotation(MaxLength.class).value();
                    if (text.length() > max) {
                        errors.add("length must be <= " + max);
                    }
                }
            }
            type = type.getSuperclass();
        }
        return errors.toArray(new String[0]);
    }
}
