import model.Account;
import model.SavingsAccount;
import util.AnnotationValidator;

import java.util.Arrays;

public class Lab07Demo {
    public static void main(String[] args) {
        Account invalid = new SavingsAccount("Riya", -100, 0);
        String[] errors = AnnotationValidator.validate(invalid);
        System.out.println("Invalid account errors: " + Arrays.toString(errors));

        Account valid = new SavingsAccount("Karan", 5000, 0);
        System.out.println("Valid account errors: " + Arrays.toString(AnnotationValidator.validate(valid)));

        Account longName = new SavingsAccount("A very long owner name that exceeds thirty characters", 100, 0);
        System.out.println("Long name errors: " + Arrays.toString(AnnotationValidator.validate(longName)));
    }
}
