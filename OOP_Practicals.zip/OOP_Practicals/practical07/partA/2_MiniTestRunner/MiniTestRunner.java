import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@interface Run {
}

class MathChecks {
    @Run
    public void additionWorks() {
        if (2 + 3 != 5) {
            throw new AssertionError("2 + 3 should be 5");
        }
    }

    @Run
    public void divisionByZeroThrows() {
        try {
            int x = 10 / 0;
            throw new AssertionError("expected ArithmeticException " + x);
        } catch (ArithmeticException expected) {
        }
    }

    @Run
    public void deliberatelyFailing() {
        throw new AssertionError("this check always fails");
    }

    public void helperNotATest() {
        System.out.println("helper called - this should never print");
    }
}

public class MiniTestRunner {
    public static void main(String[] args) throws Exception {
        MathChecks target = new MathChecks();
        int ran = 0;
        int passed = 0;
        int failed = 0;

        for (Method method : MathChecks.class.getDeclaredMethods()) {
            if (!method.isAnnotationPresent(Run.class)) {
                continue;
            }
            ran++;
            try {
                method.invoke(target);
                passed++;
                System.out.println("PASS " + method.getName());
            } catch (InvocationTargetException e) {
                failed++;
                System.out.println("FAIL " + method.getName() + " : " + e.getCause().getMessage());
            }
        }

        System.out.println("Ran " + ran + " methods, passed " + passed + ", failed " + failed);
    }
}
