import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.List;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@interface Column {
    String name();
}

class Student {
    @Column(name = "roll")
    int roll;

    @Column(name = "name")
    String name;

    @Column(name = "cgpa")
    double cgpa;

    @Column(name = "city")
    String city;

    public String toString() {
        return "Student{roll=" + roll + ", name=" + name + ", cgpa=" + cgpa + ", city=" + city + "}";
    }
}

public class ColumnMapper {
    static <T> T populate(Class<T> type, String[] header, String[] row) throws Exception {
        T object = type.getDeclaredConstructor().newInstance();
        List<String> columns = Arrays.asList(header);

        for (Field field : type.getDeclaredFields()) {
            Column column = field.getAnnotation(Column.class);
            if (column == null) {
                continue;
            }
            int index = columns.indexOf(column.name());
            if (index < 0 || index >= row.length) {
                System.out.println("Warning: column '" + column.name() + "' missing, leaving "
                        + field.getName() + " at its default");
                continue;
            }
            String raw = row[index].trim();
            field.setAccessible(true);
            Class<?> fieldType = field.getType();
            if (fieldType == int.class) {
                field.setInt(object, Integer.parseInt(raw));
            } else if (fieldType == double.class) {
                field.setDouble(object, Double.parseDouble(raw));
            } else {
                field.set(object, raw);
            }
        }
        return object;
    }

    public static void main(String[] args) throws Exception {
        String[] header = {"name", "roll", "cgpa"};
        String[] row = {"Riya", "50", "8.7"};

        Student student = populate(Student.class, header, row);
        System.out.println(student);
    }
}
