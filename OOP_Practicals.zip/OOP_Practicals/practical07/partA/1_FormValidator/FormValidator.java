import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@interface NotBlank {
}

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@interface MaxLength {
    int value();
}

class SignupForm {
    @NotBlank
    @MaxLength(10)
    String username;

    @NotBlank
    String email;

    @MaxLength(8)
    String password;

    SignupForm(String username, String email, String password) {
        this.username = username;
        this.email = email;
        this.password = password;
    }
}

public class FormValidator {
    static List<String> check(Object obj) throws IllegalAccessException {
        List<String> errors = new ArrayList<>();
        for (Field field : obj.getClass().getDeclaredFields()) {
            field.setAccessible(true);
            Object value = field.get(obj);
            if (field.isAnnotationPresent(NotBlank.class)) {
                if (value == null || value.toString().isBlank()) {
                    errors.add(field.getName() + " must not be blank");
                }
            }
            if (field.isAnnotationPresent(MaxLength.class)) {
                int max = field.getAnnotation(MaxLength.class).value();
                if (value != null && value.toString().length() > max) {
                    errors.add(field.getName() + " must be at most " + max + " characters");
                }
            }
        }
        return errors;
    }

    public static void main(String[] args) throws Exception {
        SignupForm good = new SignupForm("riya", "riya@example.com", "secret");
        SignupForm bad = new SignupForm("  ", null, "averylongpassword");

        System.out.println("Good form errors: " + check(good));
        System.out.println("Bad form errors:");
        for (String error : check(bad)) {
            System.out.println("  " + error);
        }
    }
}
