public class ChatFilter {
    private int matches;
    private final StringBuilder report = new StringBuilder();

    public void scan(String[] lines, String keyword) {
        matches = 0;
        report.setLength(0);
        for (String line : lines) {
            String[] parts = line.split(" ", 3);
            if (parts.length != 3) {
                continue;
            }
            String time = parts[0];
            String user = parts[1];
            String message = parts[2];
            if (message.toLowerCase().contains(keyword.toLowerCase())) {
                matches++;
                report.append(time).append(" ").append(user).append(": ").append(message).append("\n");
            }
        }
    }

    public int getMatches() {
        return matches;
    }

    public String getReport() {
        return report.toString();
    }
}
