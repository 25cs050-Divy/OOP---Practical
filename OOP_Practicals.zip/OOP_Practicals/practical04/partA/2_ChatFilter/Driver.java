import java.util.Scanner;

public class Driver {
    public static void main(String[] args) {
        String[] lines = {
            "10:05 alice Hello there",
            "10:06 bob Good morning everyone",
            "10:07 carol"
        };

        Scanner sc = new Scanner(System.in);
        System.out.print("Keyword: ");
        String keyword = sc.hasNextLine() ? sc.nextLine().trim() : "";

        ChatFilter filter = new ChatFilter();
        filter.scan(lines, keyword);

        System.out.println("Matches: " + filter.getMatches());
        System.out.print(filter.getReport());
        sc.close();
    }
}
