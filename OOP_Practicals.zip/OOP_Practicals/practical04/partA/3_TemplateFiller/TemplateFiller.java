import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TemplateFiller {
    private static final Pattern PLACEHOLDER = Pattern.compile("\\{(\\w+)\\}");

    public static String fill(String template, String[] names, String[] values) {
        Matcher matcher = PLACEHOLDER.matcher(template);
        StringBuilder out = new StringBuilder();
        int last = 0;
        while (matcher.find()) {
            out.append(template, last, matcher.start());
            String key = matcher.group(1);
            String replacement = "[?]";
            for (int i = 0; i < names.length; i++) {
                if (names[i].equals(key)) {
                    replacement = values[i];
                    break;
                }
            }
            out.append(replacement);
            last = matcher.end();
        }
        out.append(template.substring(last));
        return out.toString();
    }
}
