public class PasswordChecker {
    public static boolean hasMinLength(String pw) {
        return pw.length() >= 8;
    }

    public static boolean hasUppercase(String pw) {
        return pw.matches(".*[A-Z].*");
    }

    public static boolean hasDigit(String pw) {
        return pw.matches(".*[0-9].*");
    }

    public static boolean hasSpecial(String pw) {
        return pw.matches(".*[^A-Za-z0-9].*");
    }

    public static String strength(String pw) {
        int passed = 0;
        if (hasMinLength(pw)) {
            passed++;
        }
        if (hasUppercase(pw)) {
            passed++;
        }
        if (hasDigit(pw)) {
            passed++;
        }
        if (hasSpecial(pw)) {
            passed++;
        }
        if (passed <= 1) {
            return "Weak";
        }
        if (passed <= 3) {
            return "Medium";
        }
        return "Strong";
    }
}
