public class Lab04Demo {
    public static void main(String[] args) {
        System.out.println("isValidMobile(9876543210): " + Validator.isValidMobile("9876543210"));
        System.out.println("isValidMobile(12345): " + Validator.isValidMobile("12345"));
        System.out.println("isValidEmail(abc@xyz.com): " + Validator.isValidEmail("abc@xyz.com"));
        System.out.println("isValidEmail(abc@xyz): " + Validator.isValidEmail("abc@xyz"));
        System.out.println("isValidPan(ABCDE1234F): " + Validator.isValidPan("ABCDE1234F"));
        System.out.println("isValidPan(abcde1234f): " + Validator.isValidPan("abcde1234f"));
        System.out.println("isValidIfsc(SBIN0001234): " + Validator.isValidIfsc("SBIN0001234"));
        System.out.println("isValidIfsc(SBIN1001234): " + Validator.isValidIfsc("SBIN1001234"));
        System.out.println("isValidAmount(500): " + Validator.isValidAmount("500"));
        System.out.println("isValidAmount(-5): " + Validator.isValidAmount("-5"));

        Command command = CommandParser.parse("DEPOSIT AC0001 500");
        System.out.println("type=" + command.type());
        System.out.println("accountNumber=" + command.accountNumber());
        System.out.println("amount=" + command.amount());

        try {
            CommandParser.parse("DEPOSIT AC0001");
        } catch (IllegalArgumentException e) {
            System.out.println("Parse error: " + e.getMessage());
        }

        Account account = new Account("Riya", 5000);
        System.out.println(StatementFormatter.buildStatement(account));
    }
}
