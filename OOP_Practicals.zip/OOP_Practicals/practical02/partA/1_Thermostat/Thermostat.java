public class Thermostat {
    private String location;
    private int temperature;
    private static final int MIN = 16;
    private static final int MAX = 30;
    private static int activeCount = 0;

    public Thermostat(String location, int startTemp) {
        this.location = location;
        if (startTemp >= MIN && startTemp <= MAX) {
            this.temperature = startTemp;
        } else {
            this.temperature = 22;
        }
        activeCount++;
    }

    public Thermostat(String location) {
        this(location, 22);
    }

    public void raise() {
        if (temperature < MAX) {
            temperature++;
        } else {
            System.out.println("Already at maximum (30)");
        }
    }

    public void lower() {
        if (temperature > MIN) {
            temperature--;
        } else {
            System.out.println("Already at minimum (16)");
        }
    }

    public String getLocation() {
        return location;
    }

    public int getTemperature() {
        return temperature;
    }

    public static int getActiveCount() {
        return activeCount;
    }

    public static void main(String[] args) {
        Thermostat living = new Thermostat("Living Room", 25);
        Thermostat bedroom = new Thermostat("Bedroom");

        for (Thermostat t : new Thermostat[] {living, bedroom}) {
            System.out.println("--- " + t.getLocation() + " ---");
            for (int i = 0; i < 10; i++) {
                t.raise();
                System.out.println("Temperature: " + t.getTemperature());
            }
            for (int i = 0; i < 20; i++) {
                t.lower();
                System.out.println("Temperature: " + t.getTemperature());
            }
        }

        System.out.println("Active thermostats: " + Thermostat.getActiveCount());
    }
}
