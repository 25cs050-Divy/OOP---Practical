public class ParkingLot {
    private int twoWheelers;
    private int fourWheelers;
    private final int twoCap;
    private final int fourCap;
    private static long revenue = 0;

    public ParkingLot(int twoCap, int fourCap) {
        this.twoCap = twoCap;
        this.fourCap = fourCap;
    }

    public boolean park(String type) {
        if (type.equals("two")) {
            if (twoWheelers < twoCap) {
                twoWheelers++;
                revenue += 20;
                return true;
            }
        } else if (type.equals("four")) {
            if (fourWheelers < fourCap) {
                fourWheelers++;
                revenue += 40;
                return true;
            }
        }
        System.out.println("Full");
        return false;
    }

    public void leave(String type) {
        if (type.equals("two")) {
            if (twoWheelers > 0) {
                twoWheelers--;
            }
        } else if (type.equals("four")) {
            if (fourWheelers > 0) {
                fourWheelers--;
            }
        }
    }

    public int getTwoWheelers() {
        return twoWheelers;
    }

    public int getFourWheelers() {
        return fourWheelers;
    }

    public static long getRevenue() {
        return revenue;
    }

    public static void main(String[] args) {
        ParkingLot lot = new ParkingLot(2, 2);
        String[] events = {
            "park two", "park two", "park two", "park four", "park four", "park four",
            "leave two", "park two", "leave four", "leave four", "leave four"
        };

        for (String event : events) {
            String[] parts = event.split(" ");
            if (parts[0].equals("park")) {
                boolean parked = lot.park(parts[1]);
                System.out.println(event + " -> " + (parked ? "parked" : "refused"));
            } else {
                lot.leave(parts[1]);
                System.out.println(event + " -> done");
            }
        }

        System.out.println("Two-wheelers: " + lot.getTwoWheelers());
        System.out.println("Four-wheelers: " + lot.getFourWheelers());
        System.out.println("Revenue: " + ParkingLot.getRevenue());
    }
}
