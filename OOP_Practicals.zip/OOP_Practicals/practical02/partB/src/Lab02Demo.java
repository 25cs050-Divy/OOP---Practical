public class Lab02Demo {
    public static void main(String[] args) {
        Customer customer = new Customer("Riya", "riya@example.com", "9876543210");
        System.out.println("Customer: " + customer.getCustomerId() + " " + customer.getName());

        Account[] accounts = {
            new Account("Riya", 5000),
            new Account("Karan", 12000),
            new Account("Meera")
        };

        accounts[0].deposit(2000);
        System.out.println("After deposit(2000): " + accounts[0].getBalance());

        boolean ok = accounts[0].withdraw(3000);
        System.out.println("withdraw(3000): " + ok + ", balance " + accounts[0].getBalance());

        ok = accounts[0].withdraw(10000);
        System.out.println("withdraw(10000): " + ok + ", balance " + accounts[0].getBalance());

        accounts[1].deposit(500);
        accounts[2].deposit(1500);
        accounts[2].withdraw(200);

        for (Account account : accounts) {
            System.out.println(account.getAccountNumber() + " " + account.getOwnerName()
                    + " balance " + account.getBalance());
        }
    }
}
